using System;
using System.Collections.Generic;
using Xunit;
using SchedulerLibrary;

namespace SchedulerLibrary.Tests
{
    public class SchedulerTests
    {
        [Fact]
        public void TestAvailablePeriods_WithOccupiedIntervals_ReturnsCorrectFreeIntervals()
        {
            var scheduler = new Scheduler();
            DateTime workingStartTime = new DateTime(1, 1, 1, 8, 0, 0);
            DateTime workingEndTime = new DateTime(1, 1, 1, 12, 0, 0);

            List<TimeInterval> occupiedPeriods = new List<TimeInterval>
            {
                new TimeInterval(new DateTime(1, 1, 1, 10, 0, 0), 60),
                new TimeInterval(new DateTime(1, 1, 1, 11, 0, 0), 30)
            };

            List<string> expected = new List<string>
            {
                "08:00-08:30",
                "08:30-09:00",
                "09:00-09:30",
                "09:30-10:00",
                "11:30-12:00"
            };

            List<string> actual = scheduler.AvailablePeriods(workingStartTime, workingEndTime, occupiedPeriods);

            Assert.Equal(expected, actual);
        }
    }
}
