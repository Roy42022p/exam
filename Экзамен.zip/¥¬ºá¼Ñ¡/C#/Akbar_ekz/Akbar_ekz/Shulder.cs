﻿using System;
using System.Collections.Generic;

namespace SchedulerLibrary
{
    public class Scheduler
    {
        private readonly TimeSpan ConsultationTime = TimeSpan.FromMinutes(30);

        public List<string> AvailablePeriods(DateTime workingStartTime, DateTime workingEndTime, List<TimeInterval> occupiedPeriods)
        {
            List<string> availablePeriods = new List<string>();

            DateTime current = workingStartTime;

            while (current + ConsultationTime <= workingEndTime)
            {
                bool isAvailable = true;
                foreach (var period in occupiedPeriods)
                {
                    DateTime periodEnd = period.StartTime.AddMinutes(period.Duration);
                    if (current < periodEnd && current + ConsultationTime > period.StartTime)
                    {
                        isAvailable = false;
                        break;
                    }
                }

                if (isAvailable)
                {
                    availablePeriods.Add($"{current:HH:mm}-{current.Add(ConsultationTime):HH:mm}");
                }

                current = current.Add(ConsultationTime);
            }

            return availablePeriods;
        }
    }
}