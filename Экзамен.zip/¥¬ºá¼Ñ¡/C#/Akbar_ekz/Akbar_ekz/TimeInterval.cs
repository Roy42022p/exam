﻿using System;

namespace SchedulerLibrary
{
    public class TimeInterval
    {
        public DateTime StartTime { get; set; }
        public int Duration { get; set; } // in minutes

        public TimeInterval(DateTime startTime, int duration)
        {
            StartTime = startTime;
            Duration = duration;
        }
    }
}