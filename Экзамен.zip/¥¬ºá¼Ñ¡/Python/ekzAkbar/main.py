from datetime import datetime, timedelta


def available_periods(start_times, durations, working_times, consultation_time):
    working_start, working_end = working_times.split('-')
    working_start = datetime.strptime(working_start, "%H:%M")
    working_end = datetime.strptime(working_end, "%H:%M")

    busy_periods = []
    for start, duration in zip(start_times, durations):
        busy_start = datetime.strptime(start, "%H:%M")
        busy_end = busy_start + timedelta(minutes=duration)
        busy_periods.append((busy_start, busy_end))

    consultation_delta = timedelta(minutes=consultation_time)
    free_periods = []
    current_time = working_start

    while current_time + consultation_delta <= working_end:
        is_free = True
        for busy_start, busy_end in busy_periods:
            if (current_time < busy_end) and (current_time + consultation_delta > busy_start):
                is_free = False
                current_time = busy_end
                break

        if is_free:
            free_periods.append(
                f"{current_time.strftime('%H:%M')}-{(current_time + consultation_delta).strftime('%H:%M')}")
            current_time += consultation_delta

    return free_periods
