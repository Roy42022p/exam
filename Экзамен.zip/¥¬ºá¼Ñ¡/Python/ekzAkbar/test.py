import unittest
from main import available_periods


class TestAvailablePeriods(unittest.TestCase):

    def test_available_periods(self):
        print('Список свободных временных интервалов:' )
        start_times = ["10:00", "11:00"]
        durations = [60, 30]
        working_times = "08:00-12:00"
        consultation_time = 30


        result = available_periods(start_times, durations, working_times, consultation_time)
        print(result)


if __name__ == '__main__':
    unittest.main()
